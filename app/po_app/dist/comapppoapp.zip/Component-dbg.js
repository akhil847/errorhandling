sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.app.poapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);